# Expanded benchmark report

Backend: packed; packed gate: passed.
Quality prompts: 2; families: 2.
Synthetic tasks only; arithmetic uses thinking-disabled exact final answers.
Generation cap: 64 tokens; decode repeats: 2.

Quality timings contain CPU-logit instrumentation. Use controlled decode for throughput.
Controlled decode uses one prefix and synthetic inputs, not naturally generated reasoning.
CUDA timeline elapsed time is not pure kernel execution time.

Complete matched cases: 2 / 2.
Partial tables are descriptive only; comparisons exclude incomplete cases.
## Quality (random draws averaged per case)

```
     policy  budget  completed_correct  answer_correct  mean_kl  first_answer_kl  gold_nll  top1_agreement  resident_bytes  initial_resident_bytes
  automatic    0.25                0.0             0.0 0.131566         0.008734  2.663054           0.875      43296792.0              41834520.0
       int4   -1.00                0.0             0.0 0.133144         0.011768  2.740945           0.875      29577240.0              28358680.0
       int8   -1.00                0.0             0.0 0.000574         0.000130  2.989164           1.000      50923544.0              48085016.0
native_fp16   -1.00                0.0             0.0 0.000000         0.000000  2.988750           1.000      90374144.0                     NaN
     oracle    0.25                0.0             0.0 0.052036         0.018875  2.917557           0.750      43053080.0              41834520.0
 paged_fp16   -1.00                0.0             0.0 0.000022         0.000002  2.990828           1.000      91809816.0              86304792.0
     random    0.25                0.0             0.0 0.159150         0.012411  2.798814           0.750      43174936.0              41834520.0
     recent    0.25                0.0             0.0 0.019219         0.008201  2.889780           0.750      42809368.0              41834520.0
```

Incomplete or incorrect runs: 18 / 18.

## What to decide next

- Does automatic retention improve completed accuracy or KL over multiple random draws at equal bytes?
- Is any effect consistent across tasks, positions, lengths, and content seeds?
- Does steady-state decoding improve while setup/selection still dominate total cost?
- If no reliable selector benefit appears, keep the negative result and simplify or revise the score.
- Optimize packing/allocation or kernel execution only after identifying the measured bottleneck.
- Production serving, batching, standard benchmarks, other models, and true reasoning traces remain future work.