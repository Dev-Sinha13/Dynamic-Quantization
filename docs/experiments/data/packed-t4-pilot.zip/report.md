# AnchorKV T4 experiment report

GPU: Tesla T4; model: Qwen/Qwen3-0.6B@c1899de289a04d12100db370d81485cdf75e47ca.
Backend: packed; packed correctness gate: passed.
Independent cases: 6; timing repetitions: 3.

## Results

```
     policy  answer_correct  completed_correct  peak_allocated_gib  peak_incremental_mib  end_incremental_mib  resident_bytes  cache_plus_decode_seconds  accounted_total_seconds      mean_kl   max_kl  top1_agreement  gold_nll  first_answer_kl  initial_resident_bytes  resident_mib
  automatic             1.0                1.0            1.149608             32.184408            30.300618    3.083885e+07                   0.877497                 2.397786 4.242749e-03 0.020802             1.0  0.007965     1.938963e-02              30757608.0     29.410215
       int4             1.0                1.0            1.143970             26.411621            24.517415    2.477472e+07                   0.927057                 1.861363 1.921595e-02 0.094574             1.0  0.024376     9.426804e-02              24693480.0     23.627012
       int8             1.0                1.0            1.159203             42.009277            40.121582    4.113687e+07                   0.790034                 1.724340 3.404059e-06 0.000012             1.0  0.004181     6.487783e-06              40979176.0     39.231178
native_fp16             1.0                1.0            1.251874            136.904948            72.120931    7.194761e+07                   0.247729                 1.182035 0.000000e+00 0.000000             1.0  0.004174     0.000000e+00                     NaN     68.614583
     oracle             1.0                1.0            1.149502             32.076090            30.300618    3.083885e+07                   0.910205                 1.844511 1.539395e-02 0.076783             1.0  0.019794     7.547654e-02              30757608.0     29.410215
 paged_fp16             1.0                1.0            1.188575             72.086833            70.354655    7.283855e+07                   0.389287                 1.323593 5.574835e-07 0.000003             1.0  0.004183     4.522672e-07              72532712.0     69.464251
     random             1.0                1.0            1.149598             32.173991            30.300618    3.083885e+07                   0.919400                 1.853706 3.343984e-03 0.015495             1.0  0.007803     1.538317e-02              30757608.0     29.410215
     recent             1.0                1.0            1.149482             32.055257            30.300618    3.083885e+07                   0.874330                 1.808636 1.500245e-02 0.073660             1.0  0.020172     7.295991e-02              30757608.0     29.410215
```

## Interpretation boundaries

- Equal budgets apply to recent/random/automatic/oracle initial prefix caches.
- INT4 and INT8 baselines keep the same FP16 sink and rolling recent window.
- Automatic scores use only prompt-query attention and KV quantization error.
- Oracle selection uses labeled evidence; it is not an automatic result.
- Cache allocation/packing and CPU transfer are included in cache-plus-decode time.
- Automatic selection and shared prefill are included in accounted total time.
- Decode-stage peak memory excludes prefill; payload bytes include scales and tables.
- Final cache sizes may differ because policies can generate different token counts.
- The pilot is too small for broad accuracy claims. Repeated timings are not extra cases.
- Production batching, serving integration, and model-generated directive control remain future work.